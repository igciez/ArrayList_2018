#ifndef PARSER_H_INCLUDED
#define PARSER_H_INCLUDED

#include "ArrayList.h"

int parser_parseEmpleados(char* fileName, ArrayList* listaEmpleados);
int parser_guardar(char* path , ArrayList* pArrayListEmployee);


#endif // PARSER_H_INCLUDED
