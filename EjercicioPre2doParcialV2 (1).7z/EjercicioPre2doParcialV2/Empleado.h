#ifndef EMPLEADO_H_INCLUDED
#define EMPLEADO_H_INCLUDED
#include "ArrayList.h"
typedef struct
{
    int id;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;
}EEmpleado;

EEmpleado* Empleado_new();
EEmpleado* Empleado_newParametros(char* strId, char* nombre, char* strHorasTrabajadas);

int em_calcularSueldo(void* pElement);

void Empleado_imprimir(ArrayList *pArray);
void Empleado_print(EEmpleado* this);

void Empleado_delete();

int Empleado_setId(EEmpleado* this,int id);
int Empleado_getId(EEmpleado* this,int* id);

int Empleado_setNombre(EEmpleado* this,char* nombre);
int Empleado_getNombre(EEmpleado* this,char* nombre);

int Empleado_setHorasTrabajadas(EEmpleado* this,int horasTrabajadas);
int Empleado_getHorasTrabajadas(EEmpleado* this,int* horasTrabajadas);

int Empleado_setSueldo(EEmpleado* this,int sueldo);
int Empleado_getSueldo(EEmpleado* this,int* sueldo);

#endif // EMPLEADO_H_INCLUDED
