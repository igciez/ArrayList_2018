#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Empleado.h"
#include "ArrayList.h"

EEmpleado* Empleado_new()
{
    EEmpleado* this;
    this=malloc(sizeof(EEmpleado));
    return this;
}

EEmpleado* Empleado_newParametros(char* strId, char* nombre, char* strHorasTrabajadas)

{
    int id;
    int horasTrabajadas;
    EEmpleado* this;
    id = atoi(strId);
    horasTrabajadas= atoi(strHorasTrabajadas);
    this = Empleado_new();
    if(!Empleado_setId(this, id) &&
       !Empleado_setNombre(this, nombre) &&
       !Empleado_setHorasTrabajadas(this, horasTrabajadas))
    {
        return this;
    }
    Empleado_delete(this);
    return NULL;
}

int em_calcularSueldo(void* pElement)
{
    int retorno = 1;
    int auxHorasTrabajadas;
    int auxSueldo=0;


    if(pElement!= NULL)
    {

        if(!Empleado_getHorasTrabajadas(pElement, &auxHorasTrabajadas))
        {
            if( auxHorasTrabajadas > 0 && auxHorasTrabajadas < 120)
            {
                auxSueldo = auxHorasTrabajadas * 180;
               // Empleado_setSueldo(pElement, auxSueldo);
            }

            else if( auxHorasTrabajadas >= 120 && auxHorasTrabajadas <= 160)
            {
                auxSueldo = auxHorasTrabajadas * 240;
                //Empleado_setSueldo(pElement, auxSueldo);
            }
            else if( auxHorasTrabajadas >= 160 && auxHorasTrabajadas <= 240)
            {
                auxSueldo = auxHorasTrabajadas * 350;

            }
            retorno = 0;
            Empleado_setSueldo(pElement, auxSueldo);
        }

    }

    return retorno;

}

void Empleado_imprimir(ArrayList *pArray)
{
    int i;
    for(i=0; i < al_len(pArray); i++)
    {
        Empleado_print(al_get(pArray, i));
    }

}

void Empleado_print(EEmpleado* this)
{
    char nombre[64];
    int horasTrabajadas;
    int sueldo;
    int id;

    if(this != NULL)
    {
        Empleado_getId(this,&id);
        Empleado_getNombre(this,nombre);
        Empleado_getHorasTrabajadas(this,&horasTrabajadas);
        Empleado_getSueldo(this,&sueldo);
        fprintf(stdout,"Id: %d - Nombre: %s - Horas Trabajadas: %d - Sueldo: %d\n", id,nombre,horasTrabajadas,sueldo);
    }

}

void Empleado_delete(EEmpleado* this)
{
    free(this);
}

int Empleado_setId(EEmpleado* this,int id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->id=id;
        retorno=0;
    }
    return retorno;
}

int Empleado_getId(EEmpleado* this,int* id)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *id=this->id;
        retorno=0;
    }
    return retorno;
}

int Empleado_setNombre(EEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(this->nombre,nombre);
        retorno=0;
    }
    return retorno;
}

int Empleado_getNombre(EEmpleado* this,char* nombre)
{
    int retorno=-1;
    if(this!=NULL && nombre!=NULL)
    {
        strcpy(nombre,this->nombre);
        retorno=0;
    }
    return retorno;
}

int Empleado_setHorasTrabajadas(EEmpleado* this,int horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->horasTrabajadas=horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Empleado_getHorasTrabajadas(EEmpleado* this,int* horasTrabajadas)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *horasTrabajadas=this->horasTrabajadas;
        retorno=0;
    }
    return retorno;
}

int Empleado_setSueldo(EEmpleado* this,int sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        this->sueldo=sueldo;
        retorno=0;
    }
    return retorno;
}

int Empleado_getSueldo(EEmpleado* this,int* sueldo)
{
    int retorno=-1;
    if(this!=NULL)
    {
        *sueldo=this->sueldo;
        retorno=0;
    }
    return retorno;
}

