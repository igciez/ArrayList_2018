#include "ArrayList.h"
#include "Empleado.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int parser_parseEmpleados(char* fileName, ArrayList* pListaEmpleados)
{
    char id[250];
    char nombre[128];
    char horasTrabajadas[250];
    int retorno=0;

    EEmpleado* auxEmpleado;

    FILE* pFile;
    pFile = fopen(fileName, "r");
    if(pFile != NULL && al_isEmpty(pListaEmpleados))
    {
        retorno =1;

        fscanf(pFile, "%[^,],%[^,],%[^\n]\n",
               id, nombre, horasTrabajadas);
        while(!feof(pFile))
        {
             fscanf(pFile, "%[^,],%[^,],%[^\n]\n",
               id, nombre, horasTrabajadas);
            auxEmpleado = Empleado_newParametros(id, nombre, horasTrabajadas);
            al_add(pListaEmpleados, auxEmpleado);
        }
        fclose(pFile);
    }
    return retorno; // OK
}

int parser_guardar(char* path , ArrayList* pArrayListEmployee)
{
    int retorno =-1;
    int i;
    int id;
    char nombre[128];
    int horasTrabajadas;
    int sueldo;


    EEmpleado* this;
    FILE* pFile;
    pFile = fopen(path, "w");

    if(pFile != NULL)
    {
        fprintf(pFile,"id,nombre,HorasTrabajadas,Sueldo\n");

        for(i=0; i<al_len(pArrayListEmployee);i++)
        {
            retorno = 0;
            this = al_get(pArrayListEmployee, i);
            Empleado_getId(this,&id);
            Empleado_getNombre(this,nombre);
            Empleado_getHorasTrabajadas(this,&horasTrabajadas);
            Empleado_getSueldo(this,&sueldo);

            fprintf(pFile, "%d,%s,%d,%d\n", id, nombre, horasTrabajadas, sueldo);
        }
        fclose(pFile);
    }
    return retorno;
}


